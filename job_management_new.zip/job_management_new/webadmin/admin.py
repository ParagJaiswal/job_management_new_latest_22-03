from django.contrib import admin
from . models import AdminLogin,CourseData,StudentRecord


admin.site.register(AdminLogin)
admin.site.register(CourseData)
admin.site.register(StudentRecord)


