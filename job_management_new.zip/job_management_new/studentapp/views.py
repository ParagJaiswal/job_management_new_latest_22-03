from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import StudentReg
from webadmin.models import CourseData,StudentRecord
from employer.models import PostJob
import datetime



def index(request):
	return render(request,'studentapp/index.html')

def register(request):
	if request.method == 'POST':
		registeredstudent = StudentReg(Email=request.POST['txtemail'],Password=request.POST['txtpass'],Mobile=request.POST['txtmobile'],Branch=request.POST['txtbranch'],Status=0)
		registeredstudent.save()
		return redirect('login')


	return render(request,'studentapp/register.html')
def login(request):
	if request.method =='POST':
		chk = StudentReg.objects.filter(Email = request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		

		if chk.count()>0:
			p = chk[0] # Through Dictionary will iterate the value of Status because of above valu_list

			
			if p == '1':
				request.session['user'] = request.POST['txtemail']
				
				return redirect('stuhome')
			else:
						
				
				return render(request,'studentapp/login.html',{"notapprove":"Profile is not approve,contact to admin"})
			
		else:
			
			return render(request,'studentapp/login.html',{"invalid":'Incorrect User ID and Password'})

	return render(request,'studentapp/login.html')

def stuhome(request):
	if request.session.has_key('user'):
		user = request.session['user']
		show =StudentRecord.objects.filter(Email=user)
		s = StudentRecord.objects.filter(Email=user).values_list('Full_Name',flat=True)
		if s.count()>0:
			n= s[0]
			
			
		

			return render(request,'studentapp/stuhome.html',{'show':show,'user':n})
		else:
			return render(request,'studentapp/stuhome.html',{'user':user})
def addprofile(request):
	coursedata = CourseData.objects.all()
	if request.method == 'POST':
		if request.POST.get('regbtn'):
			strecord = StudentRecord(Full_Name=request.POST['txtname'],Mobile=request.POST['txtmobile'],Email=request.POST['txtemail'],Course=request.POST['course'],
				Description=request.POST['description'],Branch=request.POST['txtbranch'],Passing_Year=request.POST['txtpassingyear'],Secondary_Percentage=request.POST['txtsec'],
				Higher_Secondary_Percentage=request.POST['txthigher-sec'],Graduation_Stream=request.POST['txtgraduation-stream'],Graduation_Percentage=request.POST['txtgraduation-percentage'],
				Post_Graduation_Stream=request.POST['txtpg-stream'],Post_Graduation_Percentage=request.POST['txtpg-percentage'],Other_Certification=request.POST['txtother-qualification'])

			strecord.save()
			return redirect('stuhome')
	return render(request,'studentapp/addprofile.html',{'coursedata':coursedata})

def stuedit(request):
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method=='POST':
		if request.POST.get('update'):
			selectedstu.Full_Name=request.POST['txtname']
			selectedstu.Mobile=request.POST['txtmobile']
			selectedstu.Email=request.POST['txtemail']
			selectedstu.Course=request.POST['txtcourse']
			selectedstu.Description=request.POST['txtarea']
			selectedstu.Branch=request.POST['txtbranch']
			selectedstu.Passing_Year=request.POST['txtpassing_year']
			selectedstu.Secondary_Percentage=request.POST['txtsecondarypercentage']
			selectedstu.Higher_Secondary_Percentage=request.POST['txthighsecondarypercentage']
			selectedstu.Graduation_Stream=request.POST['graduationstream']
			selectedstu.Graduation_Percentage=request.POST['graduationpercentage']
			selectedstu.Post_Graduation_Stream=request.POST['post-graduationstream']
			selectedstu.Post_Graduation_Percentage=request.POST['post-graduationpercentage']
			selectedstu.Other_Certification=request.POST['txtother-certification']
			selectedstu.save()
			return redirect(stuhome)
		else:
			return redirect(stuhome)
	return render(request,'studentapp/stuedit.html',{'stuedit':selectedstu})

def studel(request):
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method== 'POST':
		if request.POST.get('yes'):
			selectedstu.delete()
			return redirect(stuhome)
		
	return render(request,'studentapp/studel.html',{'selectedstu':selectedstu})

def alljobs(request):
	all_jobs_record = PostJob.objects.all()
	current_date= datetime.datetime.today().strftime("%d-%m-%y")
	

	
	
	return render(request,'studentapp/alljobs.html',{'all_jobs_record':all_jobs_record,"current_date":current_date})

def techjobs(request):
	user = request.session['user']
	sr = StudentRecord.objects.filter(Email=user).values_list('Course',flat=True)
	tech = sr[0]
	job_as_per_tech = PostJob.objects.filter(Technology=tech)
	current_date= datetime.datetime.today().strftime("%d-%m-%y")

	return render(request,'studentapp/techjobs.html',{'job_as_per_tech':job_as_per_tech,"current_date":current_date})
