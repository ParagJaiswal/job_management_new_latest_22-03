from django.urls import path
from . import views

urlpatterns = [
	path('',views.index,name='index'),
	path('register',views.register,name='register'),
	path('login',views.login,name='login'),
	path('stuhome',views.stuhome,name='stuhome'),
	path('addprofile',views.addprofile,name='addprofile'),
	path('stuedit',views.stuedit,name='stuedit'),
	path('studel',views.studel,name='studel'),
	path('alljobs',views.alljobs,name='alljobs'),
	path('techjobs',views.techjobs,name='techjobs'),
	
]